import tkinter as tk
from tkinter import messagebox

class Splitter:
    def __init__(self):
        self.places = {}

    def add_place(self):
        place = self.place_entry.get().strip()
        cost = self.cost_entry.get().strip()
        if not place or not cost:
            messagebox.showerror("입력 오류", "장소와 금액을 모두 입력하세요.")
            return
        try:
            cost = float(cost)
            self.places[place] = self.places.get(place, 0) + cost
            self.update_display()
            self.place_entry.delete(0, tk.END)
            self.cost_entry.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("입력 오류", "금액은 숫자로 입력하세요.")

    def update_display(self):
        self.result_text.delete("1.0", tk.END)
        total = sum(self.places.values())
        result = "\n".join(f"{place}: {cost:.0f}원" for place, cost in self.places.items())
        result += f"\n\n총 금액: {total:.0f}원"
        self.result_text.insert(tk.END, result)

    def calculate_split(self):
        if not self.places:
            messagebox.showerror("계산 오류", "입력된 금액이 없습니다.")
            return
        try:
            num_people = int(self.people_entry.get())
            if num_people <= 0:
                raise ValueError
            total = sum(self.places.values())
            per_person = round(total / num_people, 2)
            # 결과를 텍스트 영역에 추가로 표시
            self.result_text.insert(tk.END, f"\n\n1인당 부담 금액: {per_person:.0f}원")
        except ValueError:
            messagebox.showerror("입력 오류", "참여 인원 수는 1명 이상의 숫자로 입력하세요.")

    def run(self):
        # GUI 메인 윈도우
        root = tk.Tk()
        root.title("금액 나누기 계산기")
        root.geometry("400x500")

        # 장소 입력
        tk.Label(root, text="장소:").pack(pady=5)
        self.place_entry = tk.Entry(root)
        self.place_entry.pack(pady=5)

        # 금액 입력
        tk.Label(root, text="금액:").pack(pady=5)
        self.cost_entry = tk.Entry(root)
        self.cost_entry.pack(pady=5)

        # 추가 버튼
        add_button = tk.Button(root, text="추가", command=self.add_place)
        add_button.pack(pady=10)

        # 결과 표시
        self.result_text = tk.Text(root, height=15, width=40)
        self.result_text.pack(pady=10)

        # 인원 입력 및 계산 버튼
        tk.Label(root, text="참여 인원 수:").pack(pady=5)
        self.people_entry = tk.Entry(root)
        self.people_entry.pack(pady=5)

        calculate_button = tk.Button(root, text="1인당 금액 계산", command=self.calculate_split)
        calculate_button.pack(pady=10)

        root.mainloop()

if __name__ == "__main__":
    Splitter().run()
