import tkinter as tk
from tkinter import messagebox
from geopy.distance import geodesic
from geopy.geocoders import Nominatim
import folium
from collections import Counter
import os
import webbrowser
import restaurant  # restaurant.py 추가

# 좌표 캐시 저장
coordinates_cache = {}

# 지명으로부터 위도와 경도를 반환하는 함수 (캐싱 적용)
def get_coordinates(location_name):
    if location_name in coordinates_cache:
        return coordinates_cache[location_name]
    geolocator = Nominatim(user_agent="place_locator", timeout=2)
    location = geolocator.geocode(location_name)
    if location:
        coordinates_cache[location_name] = (location.latitude, location.longitude)
        return coordinates_cache[location_name]
    else:
        raise ValueError(f"'{location_name}'에 대한 좌표를 찾을 수 없습니다.")

# 두 좌표 간의 거리 계산 함수
def calculate_distance(start_coords, end_coords):
    return geodesic(start_coords, end_coords).kilometers

# 출발지 목록에서 가장 가까운 역을 계산하는 함수
def find_best_station(start_points):
    stations = {
        "안암역": (37.5869, 127.0292),
        "강남역": (37.4979, 127.0276),
        "왕십리역": (37.5612, 127.0377),
        "건대입구역": (37.5404, 127.0709),
        "홍대입구역": (37.5572, 126.9235),
    }

    total_distances = {station: 0 for station in stations}

    for start, _ in start_points:
        start_coords = get_coordinates(start)
        for station, station_coords in stations.items():
            total_distances[station] += calculate_distance(start_coords, station_coords)

    best_station = min(total_distances, key=total_distances.get)
    return best_station, stations[best_station]

# Folium으로 지도를 생성하고 저장하는 함수
def generate_map(start_points, best_station_coords):
    """Folium으로 지도를 생성하고 저장합니다."""
    m = folium.Map(location=best_station_coords, zoom_start=12)

    # 출발지 마커
    for start, cuisine in start_points:
        coords = get_coordinates(start)
        folium.Marker(coords, popup=f"{start} ({cuisine})", icon=folium.Icon(color="blue")).add_to(m)

    # 최적의 역 마커
    folium.Marker(best_station_coords, popup="최적의 역", icon=folium.Icon(color="red")).add_to(m)

    # map.html 파일 저장 경로 수정
    map_path = os.path.join(os.getcwd(), "map.html")
    m.save(map_path)

# 버튼 클릭 이벤트: 입력받은 출발지들로 최적의 역 계산 및 지도 표시
def on_calculate():
    start_points = entry.get("1.0", tk.END).strip().split('\n')
    start_points = [line.rsplit(maxsplit=1) for line in start_points if line.strip()]

    # 입력 형식 검증
    if not all(len(point) == 2 and point[1] in {"한식", "중식", "일식", "양식"} for point in start_points):
        messagebox.showerror("입력 오류", "출발지와 음식 종류(한식/중식/일식/양식)를 공백으로 구분해 입력하세요.")
        return

    try:
        best_station, best_coords = find_best_station(start_points)
        generate_map(start_points, best_coords)

        # 음식 종류 통계 계산
        cuisines = [cuisine for _, cuisine in start_points]
        most_common_cuisine = Counter(cuisines).most_common(1)[0][0]

        result_label.config(text=f"가장 가까운 역: {best_station}\n가장 많이 선택된 음식: {most_common_cuisine}")
        show_map()

        # restaurant.py 호출
        restaurant.show_restaurant_window(best_station, most_common_cuisine)
    except ValueError as e:
        messagebox.showerror("오류", str(e))

# 웹 브라우저에서 HTML 지도 화면을 열기
def show_map():
    """웹 브라우저에서 HTML 지도 화면을 엽니다."""
    map_path = os.path.join(os.getcwd(), "map.html")
    webbrowser.open_new_tab(map_path)

# 메인 GUI 함수
def main():
    global entry, result_label

    root = tk.Tk()
    root.title("최적의 역 및 인기 음식 계산기")
    root.geometry("400x450")

    label = tk.Label(root, text="출발지와 음식 종류를 입력하세요 (예: 강남 한식):", font=("Arial", 12))
    label.pack(pady=10)

    entry = tk.Text(root, height=10, width=40)
    entry.pack(pady=10)

    calculate_button = tk.Button(root, text="계산 및 지도 보기", command=on_calculate)
    calculate_button.pack(pady=10)

    result_label = tk.Label(root, text="", font=("Arial", 12))
    result_label.pack(pady=10)

    root.mainloop()

if __name__ == "__main__":
    main()
