import requests

def fetch_weather(api_key, location="Seoul"):
    """
    OpenWeatherMap API를 사용해 서울의 날씨와 온도, 습도를 가져옵니다.
    :param api_key: 84e0a1c4316c4926d95e25ef2be85ccf
    :param location: 날씨를 확인할 위치 (기본값: 서울)
    :return: 날씨 상태, 온도, 습도 정보를 딕셔너리로 반환
    """
    url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": location,
        "appid": api_key,
        "units": "metric",
        "lang": "kr"
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        weather_data = response.json()

        # 날씨 정보 추출
        temp = weather_data["main"]["temp"]
        humidity = weather_data["main"]["humidity"]
        description = weather_data["weather"][0]["description"]

        return {
            "description": description,
            "temperature": temp,
            "humidity": humidity
        }
    except requests.exceptions.RequestException:
        return {"description": "오류", "temperature": "N/A", "humidity": "N/A"}

if __name__ == "__main__":
    API_KEY = "84e0a1c4316c4926d95e25ef2be85ccf"  # OpenWeatherMap API 키 입력
    weather = fetch_weather(API_KEY)
    print(f"날씨 상태: {weather['description']}, 온도: {weather['temperature']}°C, 습도: {weather['humidity']}%")
