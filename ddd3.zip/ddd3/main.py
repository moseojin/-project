import tkinter as tk
from tkinter import Label
import subprocess
from weather import fetch_weather  # weather.py의 fetch_weather 함수 가져오기

# OpenWeatherMap API 키 설정
API_KEY = "84e0a1c4316c4926d95e25ef2be85ccf"

def fetch_weather_info():
    """
    weather.py의 fetch_weather 함수를 호출해 날씨 데이터를 반환합니다.
    """
    weather = fetch_weather(API_KEY)
    return weather["description"], weather["temperature"], weather["humidity"]

# "놀기 전" 화면 실행 함수
def open_place_window(event=None):
    subprocess.Popen(["python", "place.py"])  # place.py 실행

# "놀기 후" 화면 실행 함수
def open_splitter_window(event=None):
    subprocess.Popen(["python", "splitter.py"])  # splitter.py 실행

def show_main_window():
    """
    메인 Tkinter 창에 날씨 정보를 포함해 기존 기능을 표시합니다.
    """
    # 날씨 정보 가져오기
    description, temperature, humidity = fetch_weather_info()

    # Tkinter GUI 설정
    root = tk.Tk()
    root.title("어디갈래?")  # 윈도우 타이틀
    root.geometry("800x600")  # 창 크기 설정
    root.resizable(False, False)  # 창 크기 고정

    # 파일 이름 레이블
    title_label = tk.Label(root, text="어디갈래?", font=("Arial", 20, "bold"), pady=10)
    title_label.pack()

    # 날씨 정보 라벨 추가
    weather_label = tk.Label(root, text=f"오늘의 날씨: {description}, 온도: {temperature}°C, 습도: {humidity}%",
                             font=("Arial", 12), pady=10)
    weather_label.pack()

    # 박스들을 담을 프레임
    frame = tk.Frame(root)
    frame.pack(pady=20)

    # 공통된 크기 변수
    box_width = 150
    box_height = 200
    font_style = ("Arial", 16, "bold")

    # 왼쪽 박스: "놀기 전"
    box1 = tk.Frame(frame, width=box_width, height=box_height, relief="ridge", borderwidth=2)
    box1.grid(row=0, column=0, padx=10)
    box1.grid_propagate(False)

    label1 = tk.Label(box1, text="놀기 전", font=font_style)
    label1.place(relx=0.5, rely=0.5, anchor="center")
    box1.bind("<Button-1>", open_place_window)

    # 오른쪽 박스: "놀기 후"
    box2 = tk.Frame(frame, width=box_width, height=box_height, relief="ridge", borderwidth=2)
    box2.grid(row=0, column=1, padx=10)
    box2.grid_propagate(False)

    label2 = tk.Label(box2, text="놀기 후", font=font_style)
    label2.place(relx=0.5, rely=0.5, anchor="center")
    box2.bind("<Button-1>", open_splitter_window)

    # Tkinter 메인 루프 실행
    root.mainloop()

def main():
    """
    GUI 실행 메인 함수
    """
    show_main_window()

if __name__ == "__main__":
    main()
