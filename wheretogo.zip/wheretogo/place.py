import customtkinter as ctk
from tkinter import messagebox
from geopy.distance import geodesic
from geopy.geocoders import Nominatim
import folium
from collections import Counter
import os
import webbrowser
import restaurant  # restaurant.py 추가

coordinates_cache = {}

# 좌표 캐시 및 가져오기
def get_coordinates(location_name):
    if location_name in coordinates_cache:
        return coordinates_cache[location_name]
    geolocator = Nominatim(user_agent="place_locator", timeout=2)
    location = geolocator.geocode(location_name)
    if location:
        coordinates_cache[location_name] = (location.latitude, location.longitude)
        return coordinates_cache[location_name]
    else:
        raise ValueError(f"'{location_name}'에 대한 좌표를 찾을 수 없습니다.")

def calculate_distance(start_coords, end_coords):
    return geodesic(start_coords, end_coords).kilometers

def find_best_station(start_points):
    stations = {
        "안암역": (37.5869, 127.0292),
        "강남역": (37.4979, 127.0276),
        "왕십리역": (37.5612, 127.0377),
        "건대입구역": (37.5404, 127.0709),
        "홍대입구역": (37.5572, 126.9235),
    }

    total_distances = {station: 0 for station in stations}
    for start, _ in start_points:
        start_coords = get_coordinates(start)
        for station, station_coords in stations.items():
            total_distances[station] += calculate_distance(start_coords, station_coords)

    best_station = min(total_distances, key=total_distances.get)
    return best_station, stations[best_station]

def generate_map(start_points, best_station_coords):
    m = folium.Map(location=best_station_coords, zoom_start=12)
    for start, cuisine in start_points:
        coords = get_coordinates(start)
        folium.Marker(coords, popup=f"{start} ({cuisine})", icon=folium.Icon(color="blue")).add_to(m)
    folium.Marker(best_station_coords, popup="모임 장소", icon=folium.Icon(color="red")).add_to(m)
    map_path = os.path.join(os.getcwd(), "map.html")
    m.save(map_path)

def show_restaurant_window(entry, result_label):
    start_points = entry.get("1.0", "end").strip().split('\n')
    start_points = [line.rsplit(maxsplit=1) for line in start_points if line.strip()]

    if not all(len(point) == 2 and point[1] in {"한식", "중식", "일식", "양식"} for point in start_points):
        messagebox.showerror("입력 오류", "출발지와 음식 종류(한식/중식/일식/양식)를 공백으로 구분해 입력하세요.")
        return
    
    try:
        best_station, _ = find_best_station(start_points)
        cuisines = [cuisine for _, cuisine in start_points]
        most_common_cuisine = Counter(cuisines).most_common(1)[0][0]
        restaurant.show_restaurant_window(best_station, most_common_cuisine)
    except ValueError as e:
        messagebox.showerror("오류", str(e))

def show_map(entry, result_label):
    start_points = entry.get("1.0", "end").strip().split('\n')
    start_points = [line.rsplit(maxsplit=1) for line in start_points if line.strip()]

    if not all(len(point) == 2 and point[1] in {"한식", "중식", "일식", "양식"} for point in start_points):
        messagebox.showerror("입력 오류", "출발지와 음식 종류(한식/중식/일식/양식)를 공백으로 구분해 입력하세요.")
        return
    
    try:
        best_station, best_coords = find_best_station(start_points)
        generate_map(start_points, best_coords)
        webbrowser.open_new_tab(os.path.join(os.getcwd(), "map.html"))
    except ValueError as e:
        messagebox.showerror("오류", str(e))

def main():
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("green")

    root = ctk.CTk()
    root.title("어디가서 뭐먹을래?")
    root.geometry("500x600")
    
    label = ctk.CTkLabel(root, text="\n어디가서 뭐먹을래?", font=("Arial", 30, "bold"), text_color="#32CD32")
    label.pack(pady=10)

    label = ctk.CTkLabel(root, text="개인별 출발지와 원하는 음식 종류를 입력하세요 \n(예: 연세로 50 한식)\n", font=("Arial", 14,"bold"))
    label.pack(pady=10)

    entry = ctk.CTkTextbox(root, height=200, width=300)
    entry.pack(pady=10)

    button_frame = ctk.CTkFrame(root)
    button_frame.pack(pady=10)

    restaurant_button = ctk.CTkButton(button_frame, text="계산하기", command=lambda: show_restaurant_window(entry, result_label), fg_color="#2E8B57")
    restaurant_button.pack(side="left", padx=10)

    map_button = ctk.CTkButton(button_frame, text="지도 보기", command=lambda: show_map(entry, result_label), fg_color="#2E8B57")
    map_button.pack(side="left", padx=10)

    result_label = ctk.CTkLabel(root, text="", font=("Arial", 14), text_color="#32CD32")
    result_label.pack(pady=10)

    root.mainloop()

if __name__ == "__main__":
    main()
