import customtkinter as ctk
from tkinter import messagebox

class SplitterApp:
    def __init__(self, root):
        self.root = root
        self.root.title("금액 나누기 계산기")
        self.root.geometry("600x500")
        ctk.set_appearance_mode("dark")  # 다크 모드
        ctk.set_default_color_theme("green")

        self.places = {}

        self.create_widgets()

    def create_widgets(self):
        # 제목
        self.title_label = ctk.CTkLabel(self.root, text="금액 나누기 계산기", font=("Arial", 30, "bold"), text_color="#32CD32")
        self.title_label.pack(pady=20)

        # 입력 프레임
        self.input_frame = ctk.CTkFrame(self.root)
        self.input_frame.pack(pady=10)

        self.place_label = ctk.CTkLabel(self.input_frame, text="장소:", font=("Arial", 14))
        self.place_label.grid(row=0, column=0, padx=5, pady=5)
        self.place_entry = ctk.CTkEntry(self.input_frame, width=200)
        self.place_entry.grid(row=0, column=1, padx=5, pady=5)

        self.cost_label = ctk.CTkLabel(self.input_frame, text="금액:", font=("Arial", 14))
        self.cost_label.grid(row=1, column=0, padx=5, pady=5)
        self.cost_entry = ctk.CTkEntry(self.input_frame, width=200)
        self.cost_entry.grid(row=1, column=1, padx=5, pady=5)

        self.add_button = ctk.CTkButton(self.input_frame, text="추가", command=self.add_place, fg_color="#2E8B57")
        self.add_button.grid(row=2, column=0, columnspan=2, pady=10)

        # 결과 표시
        self.result_text = ctk.CTkTextbox(self.root, height=150, width=500, font=("Arial", 12))
        self.result_text.pack(pady=10)

        # 인원 입력 프레임
        self.people_frame = ctk.CTkFrame(self.root)
        self.people_frame.pack(pady=10)

        self.people_label = ctk.CTkLabel(self.people_frame, text="참여 인원 수:", font=("Arial", 14))
        self.people_label.grid(row=0, column=0, padx=5, pady=5)
        self.people_entry = ctk.CTkEntry(self.people_frame, width=200)
        self.people_entry.grid(row=0, column=1, padx=5, pady=5)

        self.calculate_button = ctk.CTkButton(self.people_frame, text="1인당 금액 계산", command=self.calculate_split, fg_color="#2E8B57")
        self.calculate_button.grid(row=1, column=0, columnspan=2, pady=10)

    def add_place(self):
        place = self.place_entry.get().strip()
        cost = self.cost_entry.get().strip()
        if not place or not cost:
            messagebox.showerror("입력 오류", "장소와 금액을 모두 입력하세요.")
            return
        try:
            cost = float(cost)
            self.places[place] = self.places.get(place, 0) + cost
            self.update_display()
            self.place_entry.delete(0, "end")
            self.cost_entry.delete(0, "end")
        except ValueError:
            messagebox.showerror("입력 오류", "금액은 숫자로 입력하세요.")

    def update_display(self):
        self.result_text.delete("1.0", "end")
        total = sum(self.places.values())
        result = "\n".join(f"{place}: {cost:.0f}원" for place, cost in self.places.items())
        result += f"\n\n총 금액: {total:.0f}원"
        self.result_text.insert("end", result)

    def calculate_split(self):
        if not self.places:
            messagebox.showerror("계산 오류", "입력된 금액이 없습니다.")
            return
        try:
            num_people = int(self.people_entry.get())
            if num_people <= 0:
                raise ValueError
            total = sum(self.places.values())
            per_person = round(total / num_people, 2)
            self.result_text.insert("end", f"\n\n1인당 부담 금액: {per_person:.0f}원")
        except ValueError:
            messagebox.showerror("입력 오류", "참여 인원 수는 1명 이상의 숫자로 입력하세요.")

if __name__ == "__main__":
    root = ctk.CTk()
    app = SplitterApp(root)
    root.mainloop()
