import customtkinter as ctk
import random

class ManittoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("마니또 미션 프로그램")
        self.root.geometry("600x500")
        ctk.set_appearance_mode("dark")  # 다크 모드
        ctk.set_default_color_theme("green")

        self.create_widgets()

    def create_widgets(self):
        # 제목
        self.title_label = ctk.CTkLabel(self.root, text="마니또 미션 프로그램", font=("Arial", 30, "bold"), text_color="#32CD32")
        self.title_label.pack(pady=20)

        # 참가자 입력 프레임
        self.input_frame = ctk.CTkFrame(self.root)
        self.input_frame.pack(pady=10)

        self.participants_label = ctk.CTkLabel(self.input_frame, text="참가자 이름 (쉼표로 구분):", font=("Arial", 14))
        self.participants_label.grid(row=0, column=0, padx=5, pady=5)
        self.participants_entry = ctk.CTkEntry(self.input_frame, width=400)
        self.participants_entry.grid(row=0, column=1, padx=5, pady=5)

        self.my_name_label = ctk.CTkLabel(self.input_frame, text="본인의 이름:", font=("Arial", 14))
        self.my_name_label.grid(row=1, column=0, padx=5, pady=5)
        self.my_name_entry = ctk.CTkEntry(self.input_frame, width=400)
        self.my_name_entry.grid(row=1, column=1, padx=5, pady=5)

        # 실행 버튼
        self.run_button = ctk.CTkButton(self.root, text="마니또 선정", command=self.run_manitto, fg_color="#2E8B57")
        self.run_button.pack(pady=20)

        # 결과 출력
        self.result_label = ctk.CTkLabel(self.root, text="", font=("Arial", 14), justify="left", wraplength=550)
        self.result_label.pack(pady=20)

    def select_manitto(self, participants, my_name):
        others = [name for name in participants if name != my_name]
        if not others:
            return None
        return random.choice(others)

    def select_mission(self):
        missions = [
            "마니또에게 윙크 3번 날려주기",
            "좋아하는 간식을 몰래 주머니에 넣기",
            "상대방의 재능을 찾아 칭찬해주기",
            "안아주기",
            "놀고있을 때 친구 대신 간식을 사다 주기",
            "꽃 한 송이 선물하기",
            "자기 셀카 찍어 보내기",
            "마니또와 관련된 특별한 포즈로 사진 찍기",
            "오늘 친구가 먹고 싶어 하는 음식을 말하게 만들기",
            "웃음을 터트리게 하는 행동을 하기",
            "친구를 3번 이상 웃기기",
            "이름 대신 별명으로 부르기",
        ]
        return random.choice(missions)

    def run_manitto(self):
        participants = self.participants_entry.get().split(",")
        participants = [name.strip() for name in participants]

        my_name = self.my_name_entry.get().strip()

        if my_name not in participants:
            self.result_label.configure(text="⚠️ 본인의 이름이 참가자 명단에 없습니다.", text_color="red")
            return

        manitto = self.select_manitto(participants, my_name)
        if not manitto:
            self.result_label.configure(text="⚠️ 참가자가 본인 한 명뿐입니다.", text_color="red")
            return

        mission = self.select_mission()

        self.result_label.configure(
            text=f"✨ 당신의 마니또는 {manitto}입니다! ✨\n<오늘의 미션: {mission}>", font=("Arial", 19),text_color="white"
        )

if __name__ == "__main__":
    root = ctk.CTk()
    app = ManittoApp(root)
    root.mainloop()
