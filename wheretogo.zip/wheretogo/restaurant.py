import tkinter as tk
from tkinter import messagebox
from openpyxl import load_workbook
import os

def find_restaurants(location, cuisine):
    """
    엑셀 파일에서 위치와 음식 종류에 맞는 식당 5개를 찾습니다.
    """
    file_path = os.path.join(os.getcwd(), "wangsimni_station_restaurants.xlsx")
    if not os.path.exists(file_path):
        messagebox.showerror("파일 오류", "wangsimni_station_restaurants.xlsx 파일이 존재하지 않습니다.")
        return []

    workbook = load_workbook(file_path)
    sheet = workbook.active
    results = []

    # 데이터 탐색
    for row in sheet.iter_rows(values_only=True):
        if row[0] == cuisine and row[3] == location:
            results.append(row[2])  # 식당 이름 추가
            if len(results) == 5:
                break
    
    return results

def show_restaurant_window(location, cuisine):
    """
    새로운 창에 검색된 식당 5개를 출력합니다.
    """
    results = find_restaurants(location, cuisine)

    if not results:
        messagebox.showinfo("검색 결과", f"'{location}'에서 '{cuisine}'에 해당하는 식당이 없습니다.")
        return

    # 새로운 창 생성
    window = tk.Toplevel()
    window.title("추천 식당 목록")
    window.geometry("400x400")

    label = tk.Label(window, text=f"'{location}'에서 '{cuisine}' 추천 식당", font=("Arial", 20, "bold"))
    label.pack(pady=10)

    for restaurant in results:
        restaurant_label = tk.Label(window, text=restaurant, font=("Arial", 17))
        restaurant_label.pack(pady=5)


