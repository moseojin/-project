import customtkinter as ctk
import subprocess
from weather import fetch_weather
from PIL import Image, ImageTk  # 이미지 처리를 위해 추가

# OpenWeatherMap API 키 설정
API_KEY = "84e0a1c4316c4926d95e25ef2be85ccf"

def fetch_weather_info():
    weather = fetch_weather(API_KEY)
    return weather["description"], weather["temperature"], weather["humidity"]

def open_place_window():
    subprocess.Popen(["python", "place.py"])

def open_splitter_window():
    subprocess.Popen(["python", "splitter.py"])

def open_manitto_window():
    subprocess.Popen(["python", "manitto.py"])

def open_what_window():
    subprocess.Popen(["python", "what.py"])

def open_luckyboy_window():
    subprocess.Popen(["python", "luckyboy.py"])

def show_main_window():
    ctk.set_appearance_mode("dark")  # 다크모드 적용

    root = ctk.CTk()
    root.title("어디갈래?")
    root.geometry("800x600")
    root.resizable(False, False)

    description, temperature, humidity = fetch_weather_info()

    title_label = ctk.CTkLabel(root, text="어디갈래?", font=("Arial", 45, "bold"), text_color="#32CD32")
    title_label.pack(pady=20)

    weather_label = ctk.CTkLabel(
        root,
        text=f"오늘의 날씨: {description}, 온도: {temperature}°C, 습도: {humidity}%",
        font=("Arial", 14),
        text_color="#FFFFFF"
    )
    weather_label.pack(pady=10)

    frame = ctk.CTkFrame(root)
    frame.pack(pady=20, padx=20, fill="both", expand=True)

def show_main_window():
    ctk.set_appearance_mode("dark")  # 다크모드 적용

    root = ctk.CTk()
    root.title("어디갈래?")
    root.geometry("800x600")
    root.resizable(False, False)

    description, temperature, humidity = fetch_weather_info()

    title_label = ctk.CTkLabel(root, text="어디갈래?", font=("Arial", 45, "bold"), text_color="#32CD32")
    title_label.pack(pady=20)

    weather_label = ctk.CTkLabel(
        root,
        text=f"오늘의 날씨: {description}, 온도: {temperature}°C, 습도: {humidity}%",
        font=("Arial", 14),
        text_color="#FFFFFF"
    )
    weather_label.pack(pady=10)

    frame = ctk.CTkFrame(root)
    frame.pack(pady=20, padx=20, fill="both", expand=True)

    def create_button(parent_frame, text, command, row, column):
        button = ctk.CTkButton(
            parent_frame,
            text=text,
            font=("Arial", 16, "bold"),
            command=command,
            fg_color="#2E8B57",  # 기본 색상
            hover_color="#2E8B57",
            width=200,  # 버튼 너비 확장
            height=80   # 버튼 높이 확장
        )
        button.grid(row=row, column=column, padx=20, pady=10, sticky="nsew")

    # 그리드 레이아웃 설정
    frame.columnconfigure((0, 1, 2), weight=1)  # 세 개의 컬럼 균등하게 설정
    frame.rowconfigure((0, 1), weight=1)  # 두 개의 행 균등하게 설정

    # 버튼 배치
    create_button(frame, "어디가서 뭐먹을래?", open_place_window, 0, 0)
    create_button(frame, "마니또할래?", open_manitto_window, 0, 1)
    create_button(frame, "정산할래?", open_splitter_window, 0, 2)
    create_button(frame, "뭐할래?", open_what_window, 1, 0)
    create_button(frame, "럭키보이", open_luckyboy_window, 1, 2)

    # (1, 1) 위치에 이미지 추가
    image_path = "myungsoo.jpg"  # 표시할 이미지 파일 경로
    image = Image.open(image_path)
    image = image.resize((250, 250))  # 이미지 크기 조정
    image_tk = ImageTk.PhotoImage(image)

    image_label = ctk.CTkLabel(frame, image=image_tk, text="")  # 이미지만 표시
    image_label.image = image_tk  # 참조 유지
    image_label.grid(row=1, column=1, padx=20, pady=10, sticky="nsew")

    root.mainloop()

def main():
    show_main_window()

if __name__ == "__main__":
    main()
