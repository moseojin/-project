from flask import Flask, render_template, request
from geopy.distance import geodesic
import pandas as pd
import requests
from collections import Counter

app = Flask(__name__)

# Kakao API 설정
KAKAO_API_KEY = "454f6c86927d93060303d47ccb6e2010"
KAKAO_GEOCODE_URL = "https://dapi.kakao.com/v2/local/search/address.json"

# 주요 역 좌표
STATIONS = {
    "홍대입구역": (37.557192, 126.923867),
    "건대입구역": (37.540393, 127.070370),
    "왕십리역": (37.561533, 127.038672),
    "강남역": (37.497175, 127.027926),
    "안암역": (37.586474, 127.029305)
}

# 사용자 입력 데이터 저장
locations = []

# 엑셀 데이터 로드
def load_restaurant_data():
    file_path = "wangsimni_station_restaurants.xlsx"
    try:
        df = pd.read_excel(file_path)
        df_cleaned = df.dropna()
        return df_cleaned
    except Exception as e:
        print(f"Excel 데이터 로드 실패: {e}")
        return pd.DataFrame()

restaurants = load_restaurant_data()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/map")
def map_view():
    closest_station = None
    most_voted_cuisine = None
    top_restaurants = []

    if locations:
        # 가장 가까운 역 찾기
        station_distances = {
            station: sum(geodesic((loc['latitude'], loc['longitude']), coords).kilometers for loc in locations)
            for station, coords in STATIONS.items()
        }
        closest_station = min(station_distances, key=station_distances.get)

        # 최다 득표 음식 종류 확인
        cuisine_votes = [loc['cuisine'] for loc in locations]
        most_voted_cuisine = Counter(cuisine_votes).most_common(1)[0][0] if cuisine_votes else None

        # 조건에 맞는 식당 5개 추천
        if most_voted_cuisine and closest_station:
            filtered_restaurants = restaurants[
                (restaurants["음식 종류"] == most_voted_cuisine) &
                (restaurants["식당 위치"] == closest_station)
            ]
            top_restaurants = filtered_restaurants.sort_values("순서")["식당 이름"].head(5).tolist()

    return render_template("map.html", 
                           locations=locations,
                           closest_station=closest_station,
                           most_voted_cuisine=most_voted_cuisine,
                           top_restaurants=top_restaurants)

@app.route("/add_location", methods=["POST"])
def add_location():
    name = request.form.get("name")
    address = request.form.get("address")
    cuisine = request.form.get("cuisine")

    if not name or not address or not cuisine:
        return render_template("map.html", locations=locations, error="이름, 주소, 음식 종류를 모두 입력해주세요.")

    try:
        # Kakao API로 주소 -> 좌표 변환
        headers = {"Authorization": f"KakaoAK {KAKAO_API_KEY}"}
        response = requests.get(KAKAO_GEOCODE_URL, headers=headers, params={"query": address})
        if response.status_code == 200 and response.json()["documents"]:
            coords = response.json()["documents"][0]
            locations.append({
                "name": name,
                "address": address,
                "cuisine": cuisine,
                "latitude": float(coords["y"]),
                "longitude": float(coords["x"])
            })
    except Exception as e:
        return render_template("map.html", locations=locations, error=f"API 요청 실패: {e}")

    return render_template("map.html", locations=locations)

@app.route("/delete_location", methods=["POST"])
def delete_location():
    index = int(request.form.get("index", -1))
    if 0 <= index < len(locations):
        locations.pop(index)
    return render_template("map.html", locations=locations)

if __name__ == "__main__":
    app.run(debug=True)
