from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Kakao API 설정
KAKAO_API_KEY = "454f6c86927d93060303d47ccb6e2010"
KAKAO_GEOCODE_URL = "https://dapi.kakao.com/v2/local/search/address.json"

# 위치 데이터를 저장할 리스트
locations = []

@app.route('/')
def index():
    return render_template('map.html', locations=locations)

# 위치 추가
@app.route('/add_location', methods=['POST'])
def add_location():
    name = request.form.get('name')
    address = request.form.get('address')

    if not name or not address:
        return jsonify({'success': False, 'message': '이름과 주소를 입력해 주세요.'})

    # Kakao API로 주소를 좌표로 변환
    headers = {"Authorization": f"KakaoAK {KAKAO_API_KEY}"}
    params = {"query": address}
    response = requests.get(KAKAO_GEOCODE_URL, headers=headers, params=params)

    if response.status_code == 200 and response.json()['documents']:
        coords = response.json()['documents'][0]
        latitude = coords['y']
        longitude = coords['x']

        # 데이터 저장
        locations.append({'name': name, 'address': address, 'latitude': latitude, 'longitude': longitude})
        return jsonify({'success': True, 'locations': locations})
    else:
        return jsonify({'success': False, 'message': '좌표를 찾을 수 없습니다.'})

# 위치 삭제
@app.route('/delete_location', methods=['POST'])
def delete_location():
    index = int(request.form.get('index'))
    if 0 <= index < len(locations):
        locations.pop(index)
        return jsonify({'success': True, 'locations': locations})
    return jsonify({'success': False, 'message': '잘못된 인덱스입니다.'})

if __name__ == '__main__':
    app.run(debug=True)
