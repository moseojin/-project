from flask import Flask, render_template, request, jsonify
from geopy.distance import geodesic
import requests

app = Flask(__name__)

# Kakao API 설정
KAKAO_API_KEY = "454f6c86927d93060303d47ccb6e2010"
KAKAO_GEOCODE_URL = "https://dapi.kakao.com/v2/local/search/address.json"

# 주요 역 좌표
STATIONS = {
    "홍대입구역": (37.557192, 126.923867),
    "건대입구역": (37.540393, 127.070370),
    "왕십리역": (37.561533, 127.038672),
    "강남역": (37.497175, 127.027926),
    "안암역": (37.586474, 127.029305)
}

locations = []

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/map')
def map_view():
    closest_station = None
    station_distances = {}
    
    if locations:
        for station, coords in STATIONS.items():
            total_distance = sum(
                geodesic((loc['latitude'], loc['longitude']), coords).kilometers for loc in locations
            )
            station_distances[station] = total_distance

        closest_station = min(station_distances, key=station_distances.get)

    return render_template('map.html', locations=locations, closest_station=closest_station, station_distances=station_distances)

@app.route('/add_location', methods=['POST'])
def add_location():
    name = request.form.get('name')
    address = request.form.get('address')

    if not name or not address:
        return render_template('map.html', locations=locations, error="이름과 주소를 입력해주세요.")

    try:
        # Kakao API를 사용해 주소의 좌표 가져오기
        headers = {"Authorization": f"KakaoAK {KAKAO_API_KEY}"}
        params = {"query": address}
        response = requests.get(KAKAO_GEOCODE_URL, headers=headers, params=params, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            if data['documents']:
                coords = data['documents'][0]
                latitude = float(coords['y'])
                longitude = float(coords['x'])

                # 위치 데이터 저장
                locations.append({'name': name, 'address': address, 'latitude': latitude, 'longitude': longitude})
                return render_template('map.html', locations=locations)
            else:
                return render_template('map.html', locations=locations, error="주소를 찾을 수 없습니다.")
        else:
            return render_template('map.html', locations=locations, error=f"API 요청 실패: {response.status_code}")

    except requests.exceptions.RequestException as e:
        return render_template('map.html', locations=locations, error=f"오류 발생: {str(e)}")

@app.route('/delete_location', methods=['POST'])
def delete_location():
    index = int(request.form.get('index'))  # 삭제할 위치의 인덱스 가져오기
    if 0 <= index < len(locations):
        locations.pop(index)  # 리스트에서 해당 위치 삭제
    return render_template('map.html', locations=locations)

if __name__ == "__main__":
    app.run(debug=True)
