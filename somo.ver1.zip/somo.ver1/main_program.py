from map import map

if __name__ == '__main__':
    map.run(debug=True)
